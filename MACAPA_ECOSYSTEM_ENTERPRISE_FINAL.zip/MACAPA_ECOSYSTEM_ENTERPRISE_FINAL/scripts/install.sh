#!/bin/bash

# MACAPA Ecosystem Enterprise - Installation Script
# Instala todas las dependencias del proyecto

set -e

echo "================================"
echo "MACAPA Ecosystem Enterprise"
echo "Installation Script"
echo "================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js no está instalado. Por favor, instala Node.js 18+."
    exit 1
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python no está instalado. Por favor, instala Python 3.11+."
    exit 1
fi

# Check if Docker is installed (optional)
if ! command -v docker &> /dev/null; then
    echo "⚠️  Docker no está instalado. Podrás ejecutar el proyecto sin Docker."
fi

echo "✅ Dependencias del sistema verificadas"
echo ""

# Install Frontend Dependencies
echo "📦 Instalando dependencias del Frontend..."
cd frontend
npm install
cd ..
echo "✅ Frontend instalado"
echo ""

# Install Backend Dependencies
echo "📦 Instalando dependencias del Backend..."
cd backend
python3 -m venv venv
source venv/bin/activate 2>/dev/null || . venv/Scripts/activate
pip install -r requirements.txt
deactivate 2>/dev/null || true
cd ..
echo "✅ Backend instalado"
echo ""

echo "================================"
echo "✅ Instalación completada"
echo "================================"
echo ""
echo "Próximos pasos:"
echo "1. Frontend:  cd frontend && npm run dev"
echo "2. Backend:   cd backend && source venv/bin/activate && uvicorn app.main:app --reload"
echo "3. Docker:    docker-compose up --build"
echo ""
