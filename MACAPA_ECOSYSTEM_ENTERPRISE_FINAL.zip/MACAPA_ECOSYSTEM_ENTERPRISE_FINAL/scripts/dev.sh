#!/bin/bash

# MACAPA Ecosystem Enterprise - Development Script
# Ejecuta Frontend y Backend en paralelo

set -e

echo "================================"
echo "MACAPA Ecosystem Enterprise"
echo "Development Mode"
echo "================================"
echo ""

# Function to cleanup on exit
cleanup() {
    echo ""
    echo "Deteniendo servicios..."
    kill $FRONTEND_PID $BACKEND_PID 2>/dev/null || true
    echo "✅ Servicios detenidos"
}

trap cleanup EXIT

# Start Frontend
echo "🚀 Iniciando Frontend..."
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..
echo "✅ Frontend iniciado (PID: $FRONTEND_PID)"
echo ""

# Start Backend
echo "🚀 Iniciando Backend..."
cd backend
source venv/bin/activate 2>/dev/null || . venv/Scripts/activate
uvicorn app.main:app --reload &
BACKEND_PID=$!
cd ..
echo "✅ Backend iniciado (PID: $BACKEND_PID)"
echo ""

echo "================================"
echo "✅ Servicios ejecutándose"
echo "================================"
echo ""
echo "Frontend: http://localhost:5173"
echo "Backend:  http://localhost:8000"
echo "API Docs: http://localhost:8000/api/docs"
echo ""
echo "Presiona Ctrl+C para detener"
echo ""

# Wait for both processes
wait
