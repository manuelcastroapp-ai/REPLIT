# MACAPA Ecosystem Enterprise - Backend

Backend robusto y escalable construido con FastAPI y Python.

## Características

- ⚡ **FastAPI** - Framework web moderno y rápido
- 📚 **OpenAPI** - Documentación automática
- 🔒 **Type-Safe** - Validación automática con Pydantic
- 🚀 **Async/Await** - Soporte completo para operaciones asincrónicas
- 📊 **RESTful API** - Endpoints bien estructurados

## Instalación

```bash
pip install -r requirements.txt
```

## Desarrollo

```bash
uvicorn app.main:app --reload
```

El servidor estará disponible en `http://localhost:8000`

Documentación interactiva: `http://localhost:8000/api/docs`

## Estructura

```
app/
├── api/              # Routers de API
│   ├── projects.py   # Endpoints de proyectos
│   ├── tasks.py      # Endpoints de tareas
│   ├── analysis.py   # Endpoints de análisis
│   └── modules.py    # Endpoints de módulos
├── models/           # Modelos de datos
├── schemas/          # Esquemas Pydantic
├── services/         # Lógica de negocio
├── core/             # Configuración central
├── utils/            # Funciones utilitarias
└── main.py           # Punto de entrada
```

## Endpoints

### Projects
- `GET /api/projects` - Listar proyectos
- `GET /api/projects/{id}` - Obtener proyecto
- `POST /api/projects` - Crear proyecto
- `PUT /api/projects/{id}` - Actualizar proyecto
- `DELETE /api/projects/{id}` - Eliminar proyecto

### Tasks
- `GET /api/tasks` - Listar tareas
- `GET /api/tasks/{id}` - Obtener tarea
- `POST /api/tasks` - Crear tarea
- `PUT /api/tasks/{id}` - Actualizar tarea
- `DELETE /api/tasks/{id}` - Eliminar tarea

### Analysis
- `GET /api/analysis/performance` - Análisis de rendimiento
- `GET /api/analysis/resources` - Análisis de recursos
- `GET /api/analysis/kpis` - Indicadores clave

### Modules
- `GET /api/modules` - Listar módulos
- `GET /api/modules/{id}` - Obtener módulo
- `GET /api/modules/status/all` - Estado de todos los módulos

## Licencia

MIT
