"""Projects API Router"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

router = APIRouter()

# Models
class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = None
    status: str = "Planificado"

class Project(ProjectCreate):
    id: int
    created_at: datetime
    updated_at: datetime

# Mock data
projects_db = [
    {
        "id": 1,
        "name": "Análisis de Datos Q1",
        "description": "Análisis trimestral de datos",
        "status": "En Progreso",
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
    },
    {
        "id": 2,
        "name": "Automatización de Procesos",
        "description": "Automatizar procesos repetitivos",
        "status": "En Progreso",
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
    },
]

# Endpoints
@router.get("/", response_model=List[Project])
async def list_projects():
    """List all projects"""
    return projects_db

@router.get("/{project_id}", response_model=Project)
async def get_project(project_id: int):
    """Get a specific project"""
    project = next((p for p in projects_db if p["id"] == project_id), None)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

@router.post("/", response_model=Project)
async def create_project(project: ProjectCreate):
    """Create a new project"""
    new_project = {
        "id": len(projects_db) + 1,
        **project.dict(),
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
    }
    projects_db.append(new_project)
    return new_project

@router.put("/{project_id}", response_model=Project)
async def update_project(project_id: int, project: ProjectCreate):
    """Update a project"""
    existing = next((p for p in projects_db if p["id"] == project_id), None)
    if not existing:
        raise HTTPException(status_code=404, detail="Project not found")
    
    existing.update({
        **project.dict(),
        "updated_at": datetime.now(),
    })
    return existing

@router.delete("/{project_id}")
async def delete_project(project_id: int):
    """Delete a project"""
    global projects_db
    projects_db = [p for p in projects_db if p["id"] != project_id]
    return {"message": "Project deleted"}
