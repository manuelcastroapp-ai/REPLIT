"""Modules API Router"""

from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

router = APIRouter()

# Models
class Module(BaseModel):
    id: int
    name: str
    description: str
    version: str
    status: str

# Mock data
modules_db = [
    {
        "id": 1,
        "name": "Project Manager",
        "description": "Gestión completa de proyectos",
        "version": "1.0.0",
        "status": "Activo",
    },
    {
        "id": 2,
        "name": "Analytics Engine",
        "description": "Motor de análisis avanzado",
        "version": "2.1.0",
        "status": "Activo",
    },
    {
        "id": 3,
        "name": "Automation Suite",
        "description": "Suite de automatización",
        "version": "1.5.0",
        "status": "Activo",
    },
]

# Endpoints
@router.get("/", response_model=List[Module])
async def list_modules():
    """List all available modules"""
    return modules_db

@router.get("/{module_id}", response_model=Module)
async def get_module(module_id: int):
    """Get a specific module"""
    module = next((m for m in modules_db if m["id"] == module_id), None)
    if not module:
        return {"error": "Module not found"}
    return module

@router.get("/status/all")
async def get_all_status():
    """Get status of all modules"""
    return {
        "total": len(modules_db),
        "active": len([m for m in modules_db if m["status"] == "Activo"]),
        "modules": modules_db
    }
