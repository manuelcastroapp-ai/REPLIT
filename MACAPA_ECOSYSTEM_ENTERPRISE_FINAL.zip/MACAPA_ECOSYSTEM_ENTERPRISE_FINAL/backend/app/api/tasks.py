"""Tasks API Router"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

router = APIRouter()

# Models
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    project_id: int
    status: str = "Pendiente"

class Task(TaskCreate):
    id: int
    created_at: datetime
    updated_at: datetime

# Mock data
tasks_db = [
    {
        "id": 1,
        "title": "Revisar reportes",
        "description": "Revisar reportes mensuales",
        "project_id": 1,
        "status": "Completado",
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
    },
]

# Endpoints
@router.get("/", response_model=List[Task])
async def list_tasks():
    """List all tasks"""
    return tasks_db

@router.get("/{task_id}", response_model=Task)
async def get_task(task_id: int):
    """Get a specific task"""
    task = next((t for t in tasks_db if t["id"] == task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.post("/", response_model=Task)
async def create_task(task: TaskCreate):
    """Create a new task"""
    new_task = {
        "id": len(tasks_db) + 1,
        **task.dict(),
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
    }
    tasks_db.append(new_task)
    return new_task

@router.put("/{task_id}", response_model=Task)
async def update_task(task_id: int, task: TaskCreate):
    """Update a task"""
    existing = next((t for t in tasks_db if t["id"] == task_id), None)
    if not existing:
        raise HTTPException(status_code=404, detail="Task not found")
    
    existing.update({
        **task.dict(),
        "updated_at": datetime.now(),
    })
    return existing

@router.delete("/{task_id}")
async def delete_task(task_id: int):
    """Delete a task"""
    global tasks_db
    tasks_db = [t for t in tasks_db if t["id"] != task_id]
    return {"message": "Task deleted"}
