# MACAPA Ecosystem Enterprise

**Plataforma científica de gestión de proyectos, análisis de datos y automatización empresarial.**

Una solución empresarial completa, moderna y profesional construida con las mejores tecnologías actuales.

## 🎯 Características Principales

- **Dashboard Inteligente**: Visualización en tiempo real de métricas y KPIs
- **Gestión de Proyectos**: Organización y seguimiento completo de proyectos
- **Análisis Avanzado**: Herramientas científicas para análisis profundos
- **Automatización**: Automatiza procesos repetitivos
- **Seguridad Empresarial**: Estándares de seguridad de nivel empresarial
- **Escalabilidad**: Infraestructura robusta y confiable

## 🏗️ Arquitectura

```
MACAPA Ecosystem Enterprise
├── Frontend (React + Vite + TypeScript + Tailwind)
├── Backend (FastAPI + Python)
├── Database (PostgreSQL)
└── Docker (Containerización completa)
```

## 📋 Requisitos

- **Node.js** 18+ (Frontend)
- **Python** 3.11+ (Backend)
- **npm** 9+ (Gestor de paquetes)
- **Docker** (Opcional, para containerización)

## 🚀 Instalación Rápida

### 1. Instalación Manual

```bash
# Clonar o descargar el proyecto
cd MACAPA_ECOSYSTEM_ENTERPRISE_FINAL

# Ejecutar script de instalación
./scripts/install.sh  # Linux/Mac
# o
scripts\install.bat   # Windows
```

### 2. Instalación con Docker

```bash
docker-compose up --build
```

## 🎮 Ejecución

### Desarrollo Manual

**Terminal 1 - Frontend:**
```bash
cd frontend
npm run dev
```

**Terminal 2 - Backend:**
```bash
cd backend
source venv/bin/activate  # Linux/Mac
# o
venv\Scripts\activate.bat  # Windows

uvicorn app.main:app --reload
```

### Desarrollo Automático

```bash
./scripts/dev.sh  # Linux/Mac
```

### Producción con Docker

```bash
docker-compose up --build
```

## 📍 Acceso

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/api/docs
- **Database**: localhost:5432

## 📁 Estructura del Proyecto

```
MACAPA_ECOSYSTEM_ENTERPRISE_FINAL/
├── frontend/                    # Aplicación React
│   ├── src/
│   │   ├── pages/              # Páginas principales
│   │   ├── components/         # Componentes reutilizables
│   │   ├── hooks/              # Custom hooks
│   │   ├── utils/              # Funciones utilitarias
│   │   ├── App.tsx             # Componente raíz
│   │   ├── main.tsx            # Punto de entrada
│   │   └── index.css           # Estilos globales
│   ├── public/                 # Activos estáticos
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   └── Dockerfile
│
├── backend/                     # API FastAPI
│   ├── app/
│   │   ├── api/                # Routers
│   │   │   ├── projects.py
│   │   │   ├── tasks.py
│   │   │   ├── analysis.py
│   │   │   └── modules.py
│   │   ├── models/             # Modelos de datos
│   │   ├── schemas/            # Esquemas Pydantic
│   │   ├── services/           # Lógica de negocio
│   │   ├── core/               # Configuración
│   │   ├── utils/              # Utilidades
│   │   └── main.py             # Punto de entrada
│   ├── requirements.txt
│   ├── Dockerfile
│   └── README.md
│
├── docs/                        # Documentación
│   ├── INSTALLATION.md
│   ├── ARCHITECTURE.md
│   ├── API.md
│   └── DESIGN_SYSTEM.md
│
├── scripts/                     # Scripts de automatización
│   ├── install.sh
│   ├── install.bat
│   └── dev.sh
│
├── docker-compose.yml          # Orquestación Docker
├── DESIGN_SYSTEM.md            # Sistema de diseño
└── README.md                   # Este archivo
```

## 🎨 Sistema de Diseño

El proyecto implementa un **Sistema de Diseño Institucional** completo:

- **Paleta de Colores**: Colores primarios, secundarios y semánticos
- **Tipografía**: Inter para interfaz, JetBrains Mono para código
- **Espaciado**: Sistema modular de 8px
- **Componentes**: Botones, tarjetas, paneles, inputs
- **Temas**: Modo claro y oscuro
- **Animaciones**: Transiciones suaves y fluidas

Ver [DESIGN_SYSTEM.md](./DESIGN_SYSTEM.md) para más detalles.

## 📚 Documentación

- **[Guía de Instalación](./docs/INSTALLATION.md)** - Instrucciones detalladas
- **[Arquitectura del Sistema](./docs/ARCHITECTURE.md)** - Diseño técnico
- **[API Reference](./docs/API.md)** - Documentación de endpoints
- **[Sistema de Diseño](./DESIGN_SYSTEM.md)** - Guía visual y de componentes

## 🔗 Endpoints Principales

### Projects
- `GET /api/projects` - Listar proyectos
- `POST /api/projects` - Crear proyecto
- `GET /api/projects/{id}` - Obtener proyecto
- `PUT /api/projects/{id}` - Actualizar proyecto
- `DELETE /api/projects/{id}` - Eliminar proyecto

### Tasks
- `GET /api/tasks` - Listar tareas
- `POST /api/tasks` - Crear tarea
- `GET /api/tasks/{id}` - Obtener tarea
- `PUT /api/tasks/{id}` - Actualizar tarea
- `DELETE /api/tasks/{id}` - Eliminar tarea

### Analysis
- `GET /api/analysis/performance` - Análisis de rendimiento
- `GET /api/analysis/resources` - Análisis de recursos
- `GET /api/analysis/kpis` - Indicadores clave

### Modules
- `GET /api/modules` - Listar módulos
- `GET /api/modules/{id}` - Obtener módulo
- `GET /api/modules/status/all` - Estado de módulos

## 🛠️ Stack Tecnológico

### Frontend
- **React 18** - Librería UI
- **Vite** - Bundler rápido
- **TypeScript** - Type safety
- **Tailwind CSS** - Utilidades CSS
- **React Router** - Enrutamiento

### Backend
- **FastAPI** - Framework web
- **Python 3.11** - Lenguaje
- **Pydantic** - Validación de datos
- **SQLAlchemy** - ORM
- **PostgreSQL** - Base de datos

### DevOps
- **Docker** - Containerización
- **Docker Compose** - Orquestación
- **GitHub Actions** - CI/CD (opcional)

## 🔐 Seguridad

- CORS configurado
- Validación de entrada con Pydantic
- Type checking con TypeScript
- Variables de entorno para secretos
- Estructura modular para mantenibilidad

## 📊 Monitoreo

- Health checks en todos los servicios
- Logs estructurados
- Documentación automática con OpenAPI
- Métricas de rendimiento

## 🤝 Contribución

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver [LICENSE](./LICENSE) para más detalles.

## 📞 Soporte

Para soporte, contacta al equipo de MACAPA o abre un issue en el repositorio.

## 🎉 Agradecimientos

Construido con ❤️ por el equipo de MACAPA Ecosystem Enterprise.

---

**Versión**: 1.0.0  
**Última Actualización**: 2026-01-30  
**Estado**: ✅ Producción
