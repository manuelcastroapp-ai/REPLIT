# MACAPA ECOSYSTEM ENTERPRISE - Sistema de Diseño Institucional

## Filosofía de Diseño

**Principios Fundamentales:**
- **Serenidad**: Interfaces limpias, espacios negativos generosos, transiciones suaves
- **Ciencia**: Precisión tipográfica, grillas rigurosas, proporciones matemáticas
- **Sinfonía**: Armonía cromática, ritmo visual consistente, orquestación de elementos
- **Claridad**: Jerarquía visual evidente, intención comunicativa explícita, accesibilidad universal

---

## Paleta de Colores Institucional

### Colores Primarios
- **Azul Profundo (Primary)**: `#0F172A` - Confianza, estabilidad, profesionalismo
- **Azul Cielo (Secondary)**: `#3B82F6` - Energía, innovación, dinamismo
- **Blanco Puro (Light)**: `#FFFFFF` - Claridad, espacio, pureza

### Colores Secundarios
- **Gris Neutro (Neutral)**: `#64748B` - Textos secundarios, bordes sutiles
- **Gris Oscuro (Dark Neutral)**: `#1E293B` - Fondos, elementos de fondo
- **Verde Esmeralda (Success)**: `#10B981` - Confirmación, éxito, validación
- **Ámbar Dorado (Warning)**: `#F59E0B` - Atención, precaución, información
- **Rojo Coral (Error)**: `#EF4444` - Error, peligro, validación negativa

### Gradientes Institucionales
- **Gradiente Principal**: `linear-gradient(135deg, #0F172A 0%, #3B82F6 100%)`
- **Gradiente Sutil**: `linear-gradient(180deg, #1E293B 0%, #0F172A 100%)`

---

## Tipografía

### Familia Tipográfica Principal
- **Headings (H1-H6)**: `Inter` - Moderna, legible, profesional
- **Body Text**: `Inter` - Consistencia visual, excelente legibilidad
- **Monospace (Código)**: `JetBrains Mono` - Precisión técnica, claridad

### Escala Tipográfica (Modular Scale 1.25)
```
H1: 48px / 56px (font-weight: 700)
H2: 38px / 46px (font-weight: 700)
H3: 30px / 38px (font-weight: 600)
H4: 24px / 32px (font-weight: 600)
H5: 19px / 28px (font-weight: 500)
H6: 16px / 24px (font-weight: 500)

Body Large: 18px / 28px (font-weight: 400)
Body: 16px / 24px (font-weight: 400)
Body Small: 14px / 20px (font-weight: 400)
Caption: 12px / 18px (font-weight: 400)
```

### Pesos de Fuente
- **Regular**: 400
- **Medium**: 500
- **Semibold**: 600
- **Bold**: 700

---

## Espaciado (Sistema Modular 8px)

```
xs: 4px
sm: 8px
md: 16px
lg: 24px
xl: 32px
2xl: 48px
3xl: 64px
4xl: 96px
```

---

## Grid y Layout

### Grid Principal
- **Columnas**: 12 columnas
- **Gutter**: 24px
- **Máximo ancho**: 1440px
- **Breakpoints**:
  - Mobile: 320px
  - Tablet: 768px
  - Desktop: 1024px
  - Wide: 1440px

### Márgenes y Padding
- **Container Padding**: 24px (mobile), 32px (tablet), 48px (desktop)
- **Sección Margin**: 64px (vertical), 0px (horizontal)

---

## Componentes Base

### Botones
- **Tamaños**: Small (32px), Medium (40px), Large (48px)
- **Variantes**: Primary, Secondary, Tertiary, Destructive
- **Estados**: Default, Hover, Active, Disabled, Loading
- **Radius**: 8px
- **Transición**: 200ms ease-in-out

### Tarjetas (Cards)
- **Padding**: 24px
- **Radius**: 12px
- **Sombra**: `0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06)`
- **Borde**: 1px solid `#E2E8F0`
- **Transición**: 300ms ease-in-out

### Paneles (Panels)
- **Padding**: 32px
- **Radius**: 16px
- **Sombra**: `0 4px 6px rgba(0,0,0,0.1), 0 2px 4px rgba(0,0,0,0.06)`
- **Fondo**: `#F8FAFC`
- **Borde**: 1px solid `#E2E8F0`

### Inputs
- **Altura**: 40px
- **Padding**: 12px 16px
- **Radius**: 8px
- **Borde**: 1px solid `#CBD5E1`
- **Focus**: Borde `#3B82F6`, sombra azul suave
- **Transición**: 150ms ease-in-out

### Contenedores
- **Spacing**: Basado en grid 8px
- **Alineación**: Flexbox con gap consistente
- **Overflow**: Manejo elegante con scroll suave

---

## Sombras

```
shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05)
shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1)
shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1)
shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1)
shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25)
```

---

## Transiciones y Animaciones

### Duraciones
- **Rápida**: 150ms (interacciones simples)
- **Normal**: 200ms (cambios de estado)
- **Lenta**: 300ms (transiciones complejas)
- **Muy Lenta**: 500ms (animaciones de entrada)

### Timing Functions
- **Ease-in-out**: `cubic-bezier(0.4, 0, 0.2, 1)` - Estándar
- **Ease-out**: `cubic-bezier(0, 0, 0.2, 1)` - Salida suave
- **Ease-in**: `cubic-bezier(0.4, 0, 1, 1)` - Entrada suave

### Animaciones Predefinidas
- **Fade**: Opacidad 0 → 1
- **Slide**: Traslación suave
- **Scale**: Escalado suave
- **Pulse**: Efecto de latido sutil

---

## Iconografía

- **Tamaño Base**: 24px
- **Tamaños Disponibles**: 16px, 20px, 24px, 32px, 48px
- **Peso de Trazo**: 2px
- **Estilo**: Minimalista, geométrico, científico
- **Librería**: Lucide Icons (coherencia visual)

---

## Modo Oscuro vs Modo Claro

### Modo Claro (Default)
- **Fondo Primario**: `#FFFFFF`
- **Fondo Secundario**: `#F8FAFC`
- **Texto Primario**: `#0F172A`
- **Texto Secundario**: `#64748B`
- **Borde**: `#E2E8F0`

### Modo Oscuro
- **Fondo Primario**: `#0F172A`
- **Fondo Secundario**: `#1E293B`
- **Texto Primario**: `#F1F5F9`
- **Texto Secundario**: `#94A3B8`
- **Borde**: `#334155`

---

## Accesibilidad

- **Contraste Mínimo**: WCAG AA (4.5:1 para texto)
- **Focus States**: Visible, accesible por teclado
- **Reducción de Movimiento**: Respeta `prefers-reduced-motion`
- **Semántica HTML**: Estructura clara y significativa
- **ARIA Labels**: Descripciones explícitas donde sea necesario

---

## Responsive Design

### Principios
- **Mobile-First**: Diseño desde dispositivos pequeños
- **Escalabilidad Fluida**: Transiciones suaves entre breakpoints
- **Legibilidad**: Tamaños de fuente y espaciado adaptables
- **Toque**: Áreas interactivas mínimo 44x44px en móvil

### Breakpoints
```
sm: 640px
md: 768px
lg: 1024px
xl: 1280px
2xl: 1536px
```

---

## Patrones de Interacción

### Hover States
- **Botones**: Cambio de color + sombra elevada
- **Links**: Subrayado + color más oscuro
- **Cards**: Elevación + sombra aumentada
- **Inputs**: Borde enfatizado + fondo sutil

### Active States
- **Botones**: Escala 0.98 + color más oscuro
- **Tabs**: Subrayado + color primario
- **Menu Items**: Fondo resaltado + icono enfatizado

### Disabled States
- **Opacidad**: 50%
- **Cursor**: `not-allowed`
- **Color**: Gris neutro
- **Sin interacción**: Eventos deshabilitados

---

## Densidad Visual

### Compacta (Datos, Tablas)
- Padding reducido: 8px
- Altura de fila: 32px
- Espaciado entre elementos: 8px

### Normal (Interfaz Estándar)
- Padding: 16px
- Altura de componente: 40px
- Espaciado entre elementos: 16px

### Espaciosa (Contenido Editorial)
- Padding: 24px+
- Altura de componente: 48px+
- Espaciado entre elementos: 24px+

---

## Principios de Uso

1. **Consistencia**: Aplicar el sistema de diseño uniformemente
2. **Jerarquía**: Usar tamaños y pesos para establecer importancia
3. **Contraste**: Asegurar legibilidad y distinción visual
4. **Alineación**: Mantener rigor en grillas y espaciado
5. **Intención**: Cada decisión de diseño debe tener propósito
6. **Accesibilidad**: Diseñar para todos los usuarios
7. **Rendimiento**: Optimizar para velocidad y eficiencia

---

**Versión**: 1.0  
**Última Actualización**: 2026-01-30  
**Mantenedor**: MACAPA Design System Team
