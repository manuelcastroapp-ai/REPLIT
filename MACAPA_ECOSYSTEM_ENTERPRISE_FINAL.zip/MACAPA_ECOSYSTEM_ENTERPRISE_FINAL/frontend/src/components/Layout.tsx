import { Outlet, Link, useLocation } from 'react-router-dom'
import { useState } from 'react'

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const location = useLocation()

  const isActive = (path: string) => location.pathname === path

  return (
    <div className="flex h-screen bg-light dark:bg-primary">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-primary-light dark:bg-primary-lighter border-r border-light-border dark:border-primary-lighter transition-all duration-300 flex flex-col`}>
        {/* Logo */}
        <div className="h-16 flex items-center justify-center border-b border-light-border dark:border-primary-lighter">
          <div className="text-white font-bold text-lg">
            {sidebarOpen ? 'MACAPA' : 'M'}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          <NavLink
            to="/"
            label="Inicio"
            icon="🏠"
            isActive={isActive('/')}
            sidebarOpen={sidebarOpen}
          />
          <NavLink
            to="/dashboard"
            label="Dashboard"
            icon="📊"
            isActive={isActive('/dashboard')}
            sidebarOpen={sidebarOpen}
          />
          <NavLink
            to="/projects"
            label="Proyectos"
            icon="📁"
            isActive={isActive('/projects')}
            sidebarOpen={sidebarOpen}
          />
          <NavLink
            to="/analysis"
            label="Análisis"
            icon="🔬"
            isActive={isActive('/analysis')}
            sidebarOpen={sidebarOpen}
          />
        </nav>

        {/* Toggle Button */}
        <div className="p-4 border-t border-light-border dark:border-primary-lighter">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-primary-lighter dark:hover:bg-primary transition-colors"
          >
            <span className="text-white text-lg">{sidebarOpen ? '←' : '→'}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-light dark:bg-primary-light border-b border-light-border dark:border-primary-lighter flex items-center justify-between px-8">
          <h1 className="text-2xl font-bold text-primary dark:text-light">MACAPA Ecosystem Enterprise</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 rounded-lg hover:bg-light-subtle dark:hover:bg-primary-lighter transition-colors">
              🔔
            </button>
            <button className="p-2 rounded-lg hover:bg-light-subtle dark:hover:bg-primary-lighter transition-colors">
              👤
            </button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto bg-light dark:bg-primary">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

interface NavLinkProps {
  to: string
  label: string
  icon: string
  isActive: boolean
  sidebarOpen: boolean
}

function NavLink({ to, label, icon, isActive, sidebarOpen }: NavLinkProps) {
  return (
    <Link
      to={to}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
        isActive
          ? 'bg-secondary text-light'
          : 'text-light hover:bg-primary-lighter dark:hover:bg-primary'
      }`}
    >
      <span className="text-xl">{icon}</span>
      {sidebarOpen && <span className="text-sm font-medium">{label}</span>}
    </Link>
  )
}
