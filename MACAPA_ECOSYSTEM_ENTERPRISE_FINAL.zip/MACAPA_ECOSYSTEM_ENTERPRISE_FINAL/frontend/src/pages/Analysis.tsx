export default function Analysis() {
  return (
    <div className="container-max py-8">
      <h1 className="text-h2 font-bold text-primary dark:text-light mb-8">Análisis</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Analysis Panel 1 */}
        <div className="panel">
          <h2 className="text-h4 font-semibold text-primary dark:text-light mb-6">
            Análisis de Rendimiento
          </h2>
          <div className="h-64 bg-light-subtle dark:bg-primary-light rounded-lg flex items-center justify-center mb-4">
            <p className="text-neutral dark:text-neutral-light">
              Gráfico de rendimiento
            </p>
          </div>
          <div className="space-y-2 text-body-sm text-neutral dark:text-neutral-light">
            <p>📈 Tendencia: +12% esta semana</p>
            <p>📊 Promedio: 87.5</p>
            <p>🎯 Meta: 90</p>
          </div>
        </div>

        {/* Analysis Panel 2 */}
        <div className="panel">
          <h2 className="text-h4 font-semibold text-primary dark:text-light mb-6">
            Distribución de Recursos
          </h2>
          <div className="h-64 bg-light-subtle dark:bg-primary-light rounded-lg flex items-center justify-center mb-4">
            <p className="text-neutral dark:text-neutral-light">
              Gráfico de distribución
            </p>
          </div>
          <div className="space-y-2 text-body-sm text-neutral dark:text-neutral-light">
            <p>💼 Proyectos: 45%</p>
            <p>👥 Recursos Humanos: 35%</p>
            <p>🔧 Infraestructura: 20%</p>
          </div>
        </div>

        {/* Analysis Panel 3 */}
        <div className="panel">
          <h2 className="text-h4 font-semibold text-primary dark:text-light mb-6">
            Indicadores Clave
          </h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-body text-primary dark:text-light">ROI</span>
              <span className="text-h5 font-bold text-success">+245%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-body text-primary dark:text-light">Eficiencia</span>
              <span className="text-h5 font-bold text-success">94%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-body text-primary dark:text-light">Satisfacción</span>
              <span className="text-h5 font-bold text-success">4.8/5</span>
            </div>
          </div>
        </div>

        {/* Analysis Panel 4 */}
        <div className="panel">
          <h2 className="text-h4 font-semibold text-primary dark:text-light mb-6">
            Recomendaciones
          </h2>
          <ul className="space-y-3">
            <li className="flex gap-3">
              <span className="text-success">✓</span>
              <span className="text-body-sm text-primary dark:text-light">
                Aumentar inversión en automatización
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-warning">⚠</span>
              <span className="text-body-sm text-primary dark:text-light">
                Revisar asignación de recursos
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-info">ℹ</span>
              <span className="text-body-sm text-primary dark:text-light">
                Implementar nuevas métricas
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
