export default function Dashboard() {
  return (
    <div className="container-max py-8">
      <h1 className="text-h2 font-bold text-primary dark:text-light mb-8">Dashboard</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard label="Proyectos Activos" value="12" change="+2" />
        <StatCard label="Tareas Completadas" value="156" change="+12" />
        <StatCard label="Usuarios Activos" value="48" change="+5" />
        <StatCard label="Eficiencia" value="94%" change="+3%" />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Area */}
        <div className="lg:col-span-2">
          <div className="panel">
            <h2 className="text-h4 font-semibold text-primary dark:text-light mb-6">
              Actividad Reciente
            </h2>
            <div className="h-80 bg-light-subtle dark:bg-primary-light rounded-lg flex items-center justify-center">
              <p className="text-neutral dark:text-neutral-light">
                Gráfico de actividad (integración de datos pendiente)
              </p>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <div className="panel">
            <h3 className="text-h5 font-semibold text-primary dark:text-light mb-4">
              Próximas Tareas
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <input type="checkbox" className="mt-1" />
                <span className="text-body-sm text-primary dark:text-light">
                  Revisar reportes mensuales
                </span>
              </li>
              <li className="flex items-start gap-3">
                <input type="checkbox" className="mt-1" />
                <span className="text-body-sm text-primary dark:text-light">
                  Actualizar documentación
                </span>
              </li>
              <li className="flex items-start gap-3">
                <input type="checkbox" className="mt-1" />
                <span className="text-body-sm text-primary dark:text-light">
                  Reunión con equipo
                </span>
              </li>
            </ul>
          </div>

          <div className="panel">
            <h3 className="text-h5 font-semibold text-primary dark:text-light mb-4">
              Estadísticas
            </h3>
            <div className="space-y-2 text-body-sm text-neutral dark:text-neutral-light">
              <p>✓ 94% de tareas completadas</p>
              <p>✓ 12 proyectos en progreso</p>
              <p>✓ 0 alertas críticas</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

interface StatCardProps {
  label: string
  value: string
  change: string
}

function StatCard({ label, value, change }: StatCardProps) {
  return (
    <div className="card">
      <p className="text-body-sm text-neutral dark:text-neutral-light mb-2">
        {label}
      </p>
      <p className="text-h3 font-bold text-primary dark:text-light mb-2">
        {value}
      </p>
      <p className="text-body-sm text-success">
        {change} esta semana
      </p>
    </div>
  )
}
