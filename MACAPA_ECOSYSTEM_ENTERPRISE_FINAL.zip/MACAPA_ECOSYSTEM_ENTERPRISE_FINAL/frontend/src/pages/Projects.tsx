export default function Projects() {
  const projects = [
    {
      id: 1,
      name: 'Análisis de Datos Q1',
      status: 'En Progreso',
      progress: 65,
      team: 5,
    },
    {
      id: 2,
      name: 'Automatización de Procesos',
      status: 'En Progreso',
      progress: 45,
      team: 8,
    },
    {
      id: 3,
      name: 'Migración de Sistemas',
      status: 'Completado',
      progress: 100,
      team: 12,
    },
    {
      id: 4,
      name: 'Optimización de Performance',
      status: 'Planificado',
      progress: 0,
      team: 3,
    },
  ]

  return (
    <div className="container-max py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-h2 font-bold text-primary dark:text-light">Proyectos</h1>
        <button className="btn btn-primary">
          + Nuevo Proyecto
        </button>
      </div>

      {/* Projects Table */}
      <div className="panel overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-light-border dark:border-primary-lighter">
              <th className="text-left py-4 px-6 text-body-sm font-semibold text-primary dark:text-light">
                Nombre
              </th>
              <th className="text-left py-4 px-6 text-body-sm font-semibold text-primary dark:text-light">
                Estado
              </th>
              <th className="text-left py-4 px-6 text-body-sm font-semibold text-primary dark:text-light">
                Progreso
              </th>
              <th className="text-left py-4 px-6 text-body-sm font-semibold text-primary dark:text-light">
                Equipo
              </th>
              <th className="text-left py-4 px-6 text-body-sm font-semibold text-primary dark:text-light">
                Acciones
              </th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project) => (
              <tr
                key={project.id}
                className="border-b border-light-border dark:border-primary-lighter hover:bg-light-subtle dark:hover:bg-primary-light transition-colors"
              >
                <td className="py-4 px-6 text-body text-primary dark:text-light">
                  {project.name}
                </td>
                <td className="py-4 px-6">
                  <span className={`inline-block px-3 py-1 rounded-full text-body-sm font-medium ${
                    project.status === 'Completado'
                      ? 'bg-success bg-opacity-20 text-success'
                      : project.status === 'En Progreso'
                      ? 'bg-info bg-opacity-20 text-info'
                      : 'bg-warning bg-opacity-20 text-warning'
                  }`}>
                    {project.status}
                  </span>
                </td>
                <td className="py-4 px-6">
                  <div className="w-32 h-2 bg-light-border dark:bg-primary-lighter rounded-full overflow-hidden">
                    <div
                      className="h-full bg-secondary transition-all"
                      style={{ width: `${project.progress}%` }}
                    />
                  </div>
                  <span className="text-body-sm text-neutral dark:text-neutral-light">
                    {project.progress}%
                  </span>
                </td>
                <td className="py-4 px-6 text-body-sm text-neutral dark:text-neutral-light">
                  {project.team} miembros
                </td>
                <td className="py-4 px-6">
                  <button className="text-secondary hover:text-secondary-light transition-colors">
                    Ver →
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
