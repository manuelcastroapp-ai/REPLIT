import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="container-max py-16">
      {/* Hero Section */}
      <div className="mb-20">
        <h1 className="text-h1 font-bold text-primary dark:text-light mb-6">
          Bienvenido a MACAPA Ecosystem Enterprise
        </h1>
        <p className="text-h5 text-neutral dark:text-neutral-light mb-8 max-w-2xl">
          Plataforma científica de gestión de proyectos, análisis de datos y automatización de procesos empresariales.
        </p>
        <div className="flex gap-4">
          <Link
            to="/dashboard"
            className="btn btn-primary"
          >
            Ir al Dashboard
          </Link>
          <Link
            to="/projects"
            className="btn btn-secondary"
          >
            Ver Proyectos
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
        <FeatureCard
          icon="📊"
          title="Dashboard Inteligente"
          description="Visualiza métricas en tiempo real y toma decisiones basadas en datos precisos."
        />
        <FeatureCard
          icon="📁"
          title="Gestión de Proyectos"
          description="Organiza, planifica y ejecuta proyectos con máxima eficiencia."
        />
        <FeatureCard
          icon="🔬"
          title="Análisis Avanzado"
          description="Realiza análisis profundos con herramientas científicas de última generación."
        />
        <FeatureCard
          icon="⚙️"
          title="Automatización"
          description="Automatiza procesos repetitivos y ahorra tiempo valioso."
        />
        <FeatureCard
          icon="🔐"
          title="Seguridad Empresarial"
          description="Protege tus datos con estándares de seguridad de nivel empresarial."
        />
        <FeatureCard
          icon="🚀"
          title="Escalabilidad"
          description="Crece sin límites con una infraestructura robusta y confiable."
        />
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-primary rounded-xl p-12 text-center">
        <h2 className="text-h3 font-bold text-light mb-4">
          ¿Listo para transformar tu empresa?
        </h2>
        <p className="text-body text-light mb-8 max-w-xl mx-auto">
          Únete a miles de empresas que confían en MACAPA para impulsar su crecimiento.
        </p>
        <button className="btn bg-light text-primary hover:bg-light-subtle">
          Comenzar Ahora
        </button>
      </div>
    </div>
  )
}

interface FeatureCardProps {
  icon: string
  title: string
  description: string
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="card hover:shadow-lg transition-all">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-h5 font-semibold text-primary dark:text-light mb-2">
        {title}
      </h3>
      <p className="text-body-sm text-neutral dark:text-neutral-light">
        {description}
      </p>
    </div>
  )
}
