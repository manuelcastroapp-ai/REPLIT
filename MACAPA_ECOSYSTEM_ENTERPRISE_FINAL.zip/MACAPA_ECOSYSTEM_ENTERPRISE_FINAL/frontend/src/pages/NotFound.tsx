import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="container-max h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-h1 font-bold text-primary dark:text-light mb-4">
          404
        </h1>
        <p className="text-h4 text-neutral dark:text-neutral-light mb-8">
          Página no encontrada
        </p>
        <p className="text-body text-neutral dark:text-neutral-light mb-8 max-w-md">
          La página que buscas no existe o ha sido movida. Por favor, regresa al inicio.
        </p>
        <Link to="/" className="btn btn-primary">
          Volver al Inicio
        </Link>
      </div>
    </div>
  )
}
