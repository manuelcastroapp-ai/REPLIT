# MACAPA Ecosystem Enterprise - Frontend

Frontend moderno y profesional construido con React, Vite, TypeScript y Tailwind CSS.

## Características

- ⚡ **Vite** - Bundler ultrarrápido
- 🎨 **Tailwind CSS** - Utilidades CSS modernas
- 📱 **Responsive Design** - Compatible con todos los dispositivos
- 🌙 **Dark Mode** - Soporte para modo oscuro
- 🎯 **TypeScript** - Type-safe development
- 🚀 **Optimizado** - Rendimiento máximo

## Instalación

```bash
npm install
```

## Desarrollo

```bash
npm run dev
```

El servidor estará disponible en `http://localhost:5173`

## Build

```bash
npm run build
```

## Estructura

```
src/
├── pages/           # Páginas principales
├── components/      # Componentes reutilizables
├── hooks/          # Custom hooks
├── utils/          # Funciones utilitarias
├── assets/         # Recursos estáticos
├── App.tsx         # Componente raíz
├── main.tsx        # Punto de entrada
└── index.css       # Estilos globales
```

## Configuración

- **Vite**: `vite.config.ts`
- **TypeScript**: `tsconfig.json`
- **Tailwind**: `tailwind.config.js`
- **PostCSS**: `postcss.config.js`

## Navegación

- `/` - Página de inicio
- `/dashboard` - Dashboard principal
- `/projects` - Gestión de proyectos
- `/analysis` - Análisis y reportes

## Licencia

MIT
